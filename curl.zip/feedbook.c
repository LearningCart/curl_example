#if 0
#include <stdio.h>
#include <curl/curl.h>


int main(int argc, char **argv)
{
	CURL *curl;
	CURLcode res;
 
	curl = curl_easy_init();
	if(curl) {
		curl_easy_setopt(curl, CURLOPT_URL, "www.feedbooks.com");
		res = curl_easy_perform(curl);
 
		/* always cleanup */ 
		curl_easy_cleanup(curl);
	 }


	return 0;
}
#endif
/*****************************************************************************
 *                                   _   _ ____  _
 *  Project                     ___ | | | |  _ \| |
 *                            /  __ | | | | |_) | |
 *                            | (__ | |_| |  _ <| |___
 *                            \___|  \___/|_| \_\_____|
 *  
 *  $Id: sepheaders.c,v 1.10 2008-05-22 21:20:09 danf Exp $
 */ 
 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h> 
#include <curl/curl.h>
#include <curl/types.h>
#include <curl/easy.h>

#define	REMAINING_7	"1"
#define	REMAINING_6	"2"REMAINING_7
#define	REMAINING_5	"3"REMAINING_6
#define	REMAINING_4	"4"REMAINING_5
#define	REMAINING_3	"5"REMAINING_4
#define	REMAINING_2	"6"REMAINING_3
#define	REMAINING_1	"6"REMAINING_2
#define	PASSWORD	"7"REMAINING_1

FILE *bodyfile;
static size_t write_data(void *ptr, size_t size, size_t nmemb, void *stream)
{

  int written = fwrite(ptr, size, nmemb, (FILE *)bodyfile);
  printf("%d\r",written);
  return written;
}
 
char OutFileBuff[255];

int main(int argc, char **argv)
{
  CURL *curl_handle;
  static const char *headerfilename = "header.out";
  FILE *headerfile;
  static char *bodyfilename = "thumbnail.png";
  char *pStartLoc = NULL;  


  printf("\n1\n");
  curl_global_init(CURL_GLOBAL_ALL);
 
  /* init the curl session */ 
  curl_handle = curl_easy_init();
 
  printf("\n2\n");
  /* set URL to get */
  if(argc < 2)
  { 
	  curl_easy_setopt(curl_handle, CURLOPT_URL, "http://www.feedbooks.com/book/398.png");
	  bodyfilename = "398.png";
  }
  else
  {
	  curl_easy_setopt(curl_handle, CURLOPT_URL, argv[1]);
          pStartLoc = NULL;
	  pStartLoc = strrchr(argv[1],'/');
	  if(NULL == pStartLoc)
	  {
	  	curl_easy_setopt(curl_handle, CURLOPT_URL, "http://www.feedbooks.com/book/398.png");
		bodyfilename = "398.png";
	  }
	  else
	  {
		pStartLoc++;
		memset(OutFileBuff,0,255);
                strcpy(OutFileBuff, pStartLoc);
 		bodyfilename = OutFileBuff;
                
	  }
  }
	 
  printf("\n3\n");
  /* no progress meter please */ 
  curl_easy_setopt(curl_handle, CURLOPT_NOPROGRESS, 1L);
  curl_easy_setopt(curl_handle, CURLOPT_HEADER, 0);
  curl_easy_setopt(curl_handle, CURLOPT_PROXY,"10.1.1.22:8080"); 
  curl_easy_setopt(curl_handle, CURLOPT_PROXYAUTH, CURLAUTH_NTLM); 
  curl_easy_setopt(curl_handle, CURLOPT_PROXYUSERPWD, "mylogin:"PASSWORD); 

  printf("\n4\n");
 /* open the files */ 
  headerfile = fopen(headerfilename,"w");
  if (headerfile == NULL) {
    curl_easy_cleanup(curl_handle);
    printf("Failed\n");
    return -1;
  }
  bodyfile = fopen(bodyfilename,"wb");
  if (bodyfile == NULL) {
    curl_easy_cleanup(curl_handle);
    printf("Failed\n");
    return -1;
  }
 


  printf("\n5\n");
 
  printf("\n6\n");
  /* send all data to this function  */ 
  curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_data);
 
 
  /*
 *    * Notice here that if you want the actual data sent anywhere else but
 *       * stdout, you should consider using the CURLOPT_WRITEDATA option.  */ 
 
  /* get it! */ 
  curl_easy_perform(curl_handle);

  printf("\n7\n");
  int Count; 
  Count = 0;
  while(1)
  {
	sleep(1);
        Count++;
        if(Count > 5) break;
  }
  /* close the header file */ 
  fclose(headerfile);
  fclose(bodyfile); 
  /* cleanup curl stuff */ 
  curl_easy_cleanup(curl_handle);
 
  return 0;
}


